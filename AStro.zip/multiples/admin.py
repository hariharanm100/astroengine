from django.contrib import admin
from .models import CombinationGroupNames, CombinationGrouperChangers, Model1Charts, Model2Charts, TrendChart1, TrendChart2, TrendChart3, TrendChart4
# Register your models here.
admin.site.register(CombinationGroupNames)
admin.site.register(CombinationGrouperChangers)
admin.site.register(Model1Charts)
admin.site.register(Model2Charts)
admin.site.register(TrendChart1)
admin.site.register(TrendChart2)
admin.site.register(TrendChart3)
admin.site.register(TrendChart4)