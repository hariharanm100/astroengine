from django.apps import AppConfig


class MatchConfig(AppConfig):
    name = 'match'
